package com.example.calculator

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.text.isDigitsOnly
import androidx.room.util.copy
import com.example.calculator.ui.theme.CalculatorTheme
import com.example.calculator.ui.theme.DarkGrey
import com.example.calculator.ui.theme.LightGrey
import com.example.calculator.ui.theme.Orange


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CalculatorApp()
        }
    }
}

@Composable
fun CalculatorApp() {
    val calculatorLogic = remember { CalculatorLogic() }
    var result by remember { mutableStateOf("0") }

    Column(modifier = Modifier.background(Color.Black)) {
        Spacer(Modifier.weight(1f))
        Text(
            text = result,
            color = Color.White,
            fontSize = 48.sp,
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.End)
        )
        Spacer(modifier = Modifier.height(16.dp))

        val buttons = listOf(
            listOf("AC", "+/-", "%", "÷"),
            listOf("7", "8", "9", "x"),
            listOf("4", "5", "6", "–"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "=")
        )

        buttons.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth()) {
                row.forEachIndexed { index, label ->
                    if (label.isNotEmpty()) {
                        val modifier = if (label == "0") {
                            Modifier.weight(2f)
                        } else {
                            Modifier.weight(1f)
                        }

                        CalculatorButton(label = label, modifier = modifier) {
                            result = calculatorLogic.process(label)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun CalculatorButton(label: String, modifier: Modifier, onClick: () -> Unit) {
    val operators = listOf("÷", "x", "–", "+", "=")
    var btnColor = LightGrey
    var textColor = Color.White

    if(label.isDigitsOnly() || label == "."){
        btnColor = DarkGrey
    } else if (operators.contains(label)) {
        btnColor = Orange
    } else {
        textColor = Color.Black
    }

    Button(onClick = onClick,  modifier = modifier
        .size(110.dp, 110.dp)
        .padding(8.dp),
        shape = RoundedCornerShape(50.dp),
        colors = ButtonDefaults.buttonColors(containerColor = btnColor)
        ) {
        Text(text = label, fontSize = 30.sp, color = textColor)
    } 
}

class CalculatorLogic {
    private var currentInput: String = "0"
    private var currentResult: Double = 0.0
    private var lastOperator: String = ""
    private var isNewInput: Boolean = true
    private var hasDecimal: Boolean = false

    fun process(input: String): String {
        when {
            input.all { it.isDigit() } -> onDigitPressed(input)
            input in listOf("+", "-", "x", "÷") -> onOperatorPressed(input)
            input == "=" -> {
                calculateFinalResult()
                isNewInput = true
                hasDecimal = currentInput.contains(".")
            }
            input == "AC" -> clearAll()
            input == "+/-" -> toggleSign()
            input == "%" -> togglePercent()
            input == "." -> addDecimal()
        }
        return currentInput
    }

    private fun onDigitPressed(number: String) {
        if (isNewInput || currentInput == "0") {
            currentInput = number
            isNewInput = false
        } else {
            currentInput += number
        }
    }

    private fun onOperatorPressed(operator: String) {
        if (lastOperator.isNotEmpty()) {
            calculateFinalResult()
        }
        currentResult = currentInput.toDouble()
        lastOperator = operator
        isNewInput = true
        hasDecimal = false
    }

    private fun calculateFinalResult() {
        if (lastOperator.isNotEmpty()) {
            val currentNumber = currentInput.toDouble()
            currentResult = when (lastOperator) {
                "+" -> currentResult + currentNumber
                "-" -> currentResult - currentNumber
                "x" -> currentResult * currentNumber
                "÷" -> if (currentNumber == 0.0) Double.NaN else currentResult / currentNumber
                else -> currentResult
            }
            currentInput = formatResult(currentResult)
            lastOperator = ""
        }
    }

    private fun togglePercent() {
        if (currentInput.isNotEmpty()) {
            val value = currentInput.toDouble()
            currentInput = formatResult(value / 100)
            hasDecimal = true
        }
    }

    private fun toggleSign() {
        if (currentInput.isNotEmpty() && currentInput != "0") {
            currentInput = if (currentInput.startsWith("-")) {
                currentInput.substring(1)
            } else {
                "-$currentInput"
            }
        }
    }

    private fun clearAll() {
        currentInput = "0"
        currentResult = 0.0
        lastOperator = ""
        isNewInput = true
        hasDecimal = false
    }

    private fun addDecimal() {
        if (!hasDecimal) {
            if (isNewInput) {
                currentInput = "0."
                isNewInput = false
            } else {
                currentInput += "."
            }
            hasDecimal = true
        }
    }

    private fun formatResult(number: Double): String {
        return if (number % 1 == 0.0) {
            number.toLong().toString()
        } else {
            String.format("%.8f", number).trimEnd('0').trimEnd('.')
        }
    }
}